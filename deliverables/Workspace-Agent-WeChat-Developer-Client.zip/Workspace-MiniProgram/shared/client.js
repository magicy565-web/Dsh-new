"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorkspaceClient = exports.ClientError = void 0;
exports.conversationView = conversationView;
const blank = () => ({ artifacts: [], skills: [], memoryIds: [], connectorActions: [] });
const extensionTypes = { txt: 'text/plain', md: 'text/markdown', csv: 'text/csv', json: 'application/json', pdf: 'application/pdf', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp' };
class ClientError extends Error {
    constructor(code, message) {
        super(message);
        this.code = code;
    }
}
exports.ClientError = ClientError;
/** Same business API and shared schema as the web client; no DOM, cookie jar,
 * SSE or execution loop. Polling only invalidates a server-owned snapshot. */
class WorkspaceClient {
    constructor(platform, options) {
        this.platform = platform;
        this.options = options;
        this.session = null;
        this.token = '';
        this.pendingSend = null;
    }
    base() {
        const url = this.options.baseUrl;
        if (!/^https:\/\/[a-z0-9.-]+(?::[0-9]+)?$/i.test(url) && !(this.options.allowLoopback && /^http:\/\/127\.0\.0\.1:[0-9]+$/.test(url)))
            throw new ClientError('SERVICE_SETUP_REQUIRED', '开发版尚未绑定已授权的企业服务。');
        return url;
    }
    headers(mutating = false) {
        return { 'content-type': 'application/json', 'X-Workspace-Client': 'wechat', ...(this.token ? { 'X-Workspace-Session': this.token } : {}), ...(mutating && this.session?.csrfToken ? { 'X-CSRF-Token': this.session.csrfToken, Origin: this.base() } : {}) };
    }
    request(path, method = 'GET', data) {
        const base = this.base();
        if (!/^\/[a-zA-Z0-9_?&=.%:/-]+$/.test(path) || path.startsWith('//'))
            throw new ClientError('INVALID_PATH', '无效的业务接口。');
        return new Promise((resolve, reject) => {
            this.platform.request({ url: `${base}/api${path}`, method, data, header: this.headers(method !== 'GET'), timeout: 10000, redirect: 'manual',
                success: result => {
                    if (result.statusCode < 200 || result.statusCode >= 300) {
                        if (result.statusCode === 401 || result.statusCode === 403 && result.data?.error?.code === 'CSRF_REJECTED') {
                            this.token = '';
                            this.session = null;
                        }
                        const error = result.data?.error;
                        reject(new ClientError(error?.code || 'API_ERROR', error?.message || '操作未完成，请核对服务状态。'));
                    }
                    else
                        resolve(result.data);
                }, fail: () => reject(new ClientError(method === 'GET' ? 'NETWORK_ERROR' : 'RESULT_UNCERTAIN', method === 'GET' ? '暂时无法连接，请重试读取。' : '操作结果尚未确认；请核对原请求，不要新建重复操作。')) });
        });
    }
    async initialize() { this.session = await this.request('/session'); return this.session; }
    async login() {
        if (!this.options.loginBroker)
            throw new ClientError('LOGIN_INTEGRATION_REQUIRED', '微信身份尚未接入企业授权；需要部署方绑定真实账号。');
        this.base(); // No WeChat-code acquisition without a configured service.
        const code = await new Promise((resolve, reject) => this.platform.login({ success: result => result.code ? resolve(result.code) : reject(new ClientError('LOGIN_REQUIRED', '微信登录未取得授权码。')), fail: () => reject(new ClientError('LOGIN_REQUIRED', '微信登录未完成。')) }));
        const result = await this.options.loginBroker(code);
        if (!/^[A-Za-z0-9_-]{43}$/.test(result.token) || !result.session.authenticated)
            throw new ClientError('LOGIN_REQUIRED', '企业授权未完成。');
        this.token = result.token;
        try {
            // The broker cannot grant a role. Verify the actual existing enterprise
            // session through the same signed ingress before presenting login success.
            const actual = await this.initialize();
            if (!actual.authenticated || !actual.user || actual.user.id !== result.session.user?.id)
                throw new ClientError('LOGIN_IDENTITY_MISMATCH', '微信身份与实际企业会话未核对一致。');
            this.session = actual;
            return actual;
        }
        catch (error) {
            this.token = '';
            this.session = null;
            throw error;
        }
    }
    async bootstrap() { return this.request('/bootstrap'); }
    async mainConversation(snapshot) {
        const native = snapshot.museBinding?.conversationId;
        if (native && snapshot.conversations.some(value => value.id === native))
            return native;
        if (snapshot.conversations.length)
            return snapshot.conversations[0].id;
        const result = await this.request('/conversations', 'POST', { title: '主会话' });
        return result.conversation.id;
    }
    requestId() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, letter => { const value = Math.floor(Math.random() * 16); return (letter === 'x' ? value : (value & 3) | 8).toString(16); }); }
    async send(conversationId, content, artifacts = []) {
        if (!content.trim())
            throw new ClientError('INPUT_REQUIRED', '说说你想完成的事。');
        if (this.pendingSend)
            throw new ClientError('RESULT_UNCERTAIN', '先核对上一条原请求的结果。');
        const inputContext = blank();
        // Existing policy does not parse PDF/images or export private library assets.
        inputContext.artifacts = artifacts.filter(value => ['text/plain', 'text/markdown', 'text/csv', 'application/json'].includes(value.mimeType || '')).map(value => ({ id: value.id, version: value.version }));
        this.pendingSend = { conversationId, body: { content: content.trim(), requestId: this.requestId(), inputContext, workspaceExecution: true, provider: 'pi' } };
        return this.retrySend();
    }
    async retrySend() {
        if (!this.pendingSend)
            throw new ClientError('NO_PENDING_REQUEST', '没有需要核对的原请求。');
        const pending = this.pendingSend;
        const result = await this.request(`/conversations/${encodeURIComponent(pending.conversationId)}/messages`, 'POST', pending.body);
        this.pendingSend = null;
        return result;
    }
    get uncertain() { return Boolean(this.pendingSend); }
    async action(card, confirmed, conversationId) {
        if (!confirmed)
            throw new ClientError('APPROVAL_REQUIRED', '需要明确确认本次具体操作。');
        if (card.muse) {
            if (!conversationId || !card.orderId || !card.reviewHash || !['approve', 'dispatch', 'accept', 'cancel', 'refresh'].includes(card.operation || ''))
                throw new ClientError('INVALID_ACTION', '需要核对原 Muse 订单与本次具体操作。');
            return this.request(`/conversations/${encodeURIComponent(conversationId)}/muse-delegations/${encodeURIComponent(card.orderId)}/${card.operation}`, 'POST', { confirmed: true, expectedReviewHash: card.reviewHash, ...(card.operation === 'accept' ? { receiptHash: card.receiptHash } : {}) });
        }
        if (!card.runId)
            throw new ClientError('INVALID_ACTION', '需要核对原运行。');
        const id = encodeURIComponent(card.runId);
        if (card.operation === 'approve')
            return this.request(`/runs/${id}/action-decision`, 'POST', { proposalId: card.proposalId, decision: 'approved', confirmed: true });
        if (card.operation === 'resume')
            return this.request(`/runs/${id}/resume`, 'POST', { proposalId: card.proposalId, requestId: this.requestId() });
        if (card.operation === 'recover')
            return this.request(`/runs/${id}/retry`, 'POST', { requestId: this.requestId() });
        if (card.operation === 'cancel')
            return this.request(`/runs/${id}/cancel`, 'POST', {});
        throw new ClientError('INVALID_ACTION', '未知操作。');
    }
    async library() {
        const [products, company, documents] = await Promise.all([this.request('/library/products'), this.request('/library/company'), this.request('/library/documents')]);
        return { products: products.items, company: company.company, documents: documents.items };
    }
    references(id) { return this.request(`/conversations/${encodeURIComponent(id)}/library-references`); }
    museDelegations(id) { return this.request(`/conversations/${encodeURIComponent(id)}/muse-delegations`); }
    saveReferences(value) { return this.request(`/conversations/${encodeURIComponent(value.conversationId)}/library-references`, 'POST', { references: { products: value.products, documents: value.documents }, expectedRevision: value.revision, requestId: this.requestId() }); }
    async upload(conversationId, filename, filePath, size) {
        const extension = filename.split('.').pop()?.toLowerCase() || '';
        if (!extensionTypes[extension] || size > 5 * 1024 * 1024)
            throw new ClientError('FILE_UNSUPPORTED', '请选择 5MiB 以内的图片、PDF、文本或表格文件。');
        const base64 = await new Promise((resolve, reject) => this.platform.getFileSystemManager().readFile({ filePath, encoding: 'base64', success: result => resolve(String(result.data)), fail: () => reject(new ClientError('FILE_READ_FAILED', '文件无法读取。')) }));
        const result = await this.request('/artifacts', 'POST', { filename, mimeType: extensionTypes[extension], base64, sourceConversationId: conversationId, requestId: this.requestId() });
        return { id: result.artifact.id, version: result.artifact.currentVersion, sha256: result.artifact.sha256, filename: result.artifact.filename, mimeType: result.artifact.mimeType };
    }
    async download(file, muse = false) {
        if (!/^[a-zA-Z0-9_.:-]{1,160}$/.test(file.id) || !Number.isInteger(file.version) || file.version < 1 || !/^[a-f0-9]{64}$/.test(file.sha256))
            throw new ClientError('FILE_REFERENCE_INVALID', '文件引用需要核对。');
        const path = muse ? `/muse-worker-files/${encodeURIComponent(file.id)}` : `/artifacts/${encodeURIComponent(file.id)}/download`;
        const tempFilePath = await new Promise((resolve, reject) => this.platform.downloadFile({ url: `${this.base()}/api${path}?version=${file.version}&sha256=${file.sha256}`, header: this.headers(), timeout: 20000, success: result => result.statusCode === 200 ? resolve(result.tempFilePath) : reject(new ClientError('FILE_DENIED', '当前账号无法读取此文件版本。')), fail: () => reject(new ClientError('FILE_DOWNLOAD_FAILED', '文件读取未完成，请重试原版本。')) }));
        const digest = await new Promise((resolve, reject) => this.platform.getFileSystemManager().getFileInfo({ filePath: tempFilePath, digestAlgorithm: 'sha256', success: result => resolve(result.digest), fail: () => reject(new ClientError('FILE_VERIFY_FAILED', '文件校验未完成。')) }));
        if (digest !== file.sha256)
            throw new ClientError('FILE_HASH_MISMATCH', '文件与原回执不一致，已拒绝打开。');
        return tempFilePath;
    }
}
exports.WorkspaceClient = WorkspaceClient;
function conversationView(snapshot, conversationId, delegations = []) {
    const messages = snapshot.messages.filter(value => value.conversationId === conversationId);
    const runs = (snapshot.runs || []).filter(value => value.conversationId === conversationId);
    const cards = [];
    for (const run of runs) {
        if (run.status === 'running' || run.status === 'queued')
            cards.push({ id: run.id, kind: 'progress', title: run.status === 'queued' ? '任务已排队' : '正在处理', detail: '服务端持续保存进度，离开页面后可回来查看。', runId: run.id, operation: 'cancel' });
        if (run.status === 'interrupted')
            cards.push({ id: run.id, kind: 'progress', title: '任务已中断', detail: '恢复原持久提交前，会重新核对权限与输入。', runId: run.id, operation: 'recover' });
        for (const proposal of run.proposals || [])
            if (proposal.status === 'pending' || proposal.status === 'approved')
                cards.push({ id: proposal.id, kind: 'approval', title: proposal.status === 'approved' ? '已批准，等待明确继续' : '请确认具体操作', detail: `${proposal.action} · ${proposal.resource}\n${JSON.stringify(proposal.payload)}`, runId: run.id, proposalId: proposal.id, operation: proposal.status === 'approved' ? 'resume' : 'approve' });
    }
    for (const message of messages) {
        const reference = message.artifactReference;
        const artifact = (snapshot.artifacts || []).find(value => value.id === reference?.id && value.sourceRunId === message.runId && value.sourceConversationId === conversationId);
        const version = artifact?.versions.find(value => value.version === reference?.version && value.sha256 === reference?.sha256);
        if (reference && version)
            cards.push({ id: `${reference.id}:${reference.version}`, kind: 'file', title: version.filename, detail: `原文件 v${reference.version} · 点击校验后打开`, file: { ...reference, filename: version.filename, mimeType: version.mimeType } });
    }
    for (const item of delegations) {
        if (item.conversationId !== conversationId || !/^[a-f0-9]{64}$/.test(item.reviewHash))
            continue;
        const scope = { muse: true, orderId: item.orderId, reviewHash: item.reviewHash, receiptHash: item.receiptHash || undefined };
        const detail = `${item.review.product} · ${item.review.market}\n${item.review.objective}\n上限 ${item.review.budgetCredits} credits。派发不是唤醒或模型执行证据。`;
        if (item.phase === 'review_required')
            cards.push({ id: `muse:${item.orderId}`, kind: 'approval', title: '审阅原 Muse 订单', detail, operation: 'approve', ...scope });
        else if (item.phase === 'approved')
            cards.push({ id: `muse:${item.orderId}`, kind: 'approval', title: '原订单已批准，等待派发', detail, operation: 'dispatch', ...scope });
        else if (item.phase === 'result_returned' && item.receiptHash && item.returnedHash === item.receiptHash) {
            cards.push({ id: `muse:${item.orderId}`, kind: 'approval', title: '验收原 Muse 回执', detail: '请核对真实文件与范围。回执不等于唤醒、模型执行或独立验收通过。', operation: 'accept', ...scope });
            for (const file of item.receipt?.files || [])
                if (typeof file.id === 'string' && file.version === 1 && /^[a-f0-9]{64}$/.test(file.sha256))
                    cards.push({ id: `muse-file:${file.id}`, kind: 'file', title: file.filename || 'Muse 原文件', detail: '原回执文件 · 校验确切版本与 SHA 后打开', file, muse: true });
        }
        else if (!['enterprise_accepted', 'cancelled'].includes(item.phase)) {
            const phase = { queued: '已排队，等待领取', claimed: '已领取，执行待核对', result_ready: '回执待核对', reconciliation_required: '原尝试待核对', cancel_requested: '等待停止确认' }[item.phase] || '进度待核对';
            cards.push({ id: `muse:${item.orderId}`, kind: 'progress', title: `Muse 原任务 · ${phase}`, detail, operation: 'refresh', ...scope });
            cards.push({ id: `muse-stop:${item.orderId}`, kind: 'progress', title: '请求停止原 Muse 任务', detail: '停止要等待原执行端确认，不能把客户端停止等待当作工作已经中止。', operation: 'cancel', ...scope });
        }
    }
    return { messages, cards, busy: runs.some(value => value.status === 'running' || value.status === 'queued') };
}
