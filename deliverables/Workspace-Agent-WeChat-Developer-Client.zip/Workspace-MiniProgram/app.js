"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./shared/client");
// Host/account setup supplies the reviewed HTTPS ingress and login broker.
// No model key, Connector credential or enterprise membership is in this app.
const client = new client_1.WorkspaceClient(wx, { baseUrl: '' });
App({ globalData: { client }, onHide() { } });
