"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const identities = new WeakMap();
Component({
    options: { styleIsolation: 'shared' },
    properties: { review: { type: Object, value: null, observer(raw) {
                const value = raw;
                if (!value) {
                    identities.delete(this);
                    this.setData({ target: null, checked: [], draftChecked: false, imagesChecked: false, publishChecked: false, repairChecked: false, observedChecked: false, notifyChecked: false, nativeChecked: false, executeChecked: false, readChecked: false, ready: false, error: '' });
                    return;
                }
                if (identities.get(this) !== value.key) {
                    identities.set(this, value.key);
                    this.setData({ checked: [], draftChecked: false, imagesChecked: false, publishChecked: false, repairChecked: false, observedChecked: false, notifyChecked: false, nativeChecked: false, executeChecked: false, readChecked: false, ready: false, error: '' });
                }
                this.setData({ target: value });
            } }, busy: { type: Boolean, value: false }, uncertain: { type: Boolean, value: false }, serverError: { type: String, value: '' } },
    data: { target: null, checked: [], draftChecked: false, imagesChecked: false, publishChecked: false, repairChecked: false, observedChecked: false, notifyChecked: false, nativeChecked: false, executeChecked: false, readChecked: false, ready: false, error: '' },
    methods: {
        consent(event) { if (this.data.busy || this.data.uncertain)
            return; const checked = event.detail.value, t = this.data.target, ready = !!t && t.allowConfirm && (t.stage === 'prepare' || t.stage === 'decision' ? t.action === 'draft' ? checked.includes('draft') && (!t.hasImages || checked.includes('images')) : t.action === 'repair_draft' ? checked.includes('repair') && (!t.observedMediaRequired || checked.includes('observed')) : t.action === 'notification' ? checked.includes('notify') : checked.includes('publish') : t.stage === 'native' ? checked.includes('native') : t.stage === 'reconcile' ? checked.includes('read') : checked.includes('execute')); this.setData({ checked, ready, draftChecked: checked.includes('draft'), imagesChecked: checked.includes('images'), publishChecked: checked.includes('publish'), repairChecked: checked.includes('repair'), observedChecked: checked.includes('observed'), notifyChecked: checked.includes('notify'), nativeChecked: checked.includes('native'), executeChecked: checked.includes('execute'), readChecked: checked.includes('read'), error: '' }); },
        confirm() {
            const t = this.data.target;
            if (!t || this.data.busy || this.data.uncertain || !t.allowConfirm)
                return;
            const content = t.stage === 'prepare' || t.stage === 'decision', valid = content ? t.action === 'draft' ? this.data.draftChecked && (!t.hasImages || this.data.imagesChecked) : t.action === 'repair_draft' ? this.data.repairChecked && (!t.observedMediaRequired || this.data.observedChecked) : t.action === 'notification' ? this.data.notifyChecked : this.data.publishChecked : t.stage === 'native' ? this.data.nativeChecked : t.stage === 'reconcile' ? this.data.readChecked : this.data.executeChecked;
            if (!valid) {
                this.setData({ error: t.action === 'repair_draft' ? '请明确确认缺失步骤修复，并另行确认需要采用的观察媒体身份。' : '请分别明确确认本次准确操作和图片传输范围。' });
                return;
            }
            this.triggerEvent('confirm', { ...t, ...(t.action === 'repair_draft' && content ? { approveObservedMedia: this.data.observedChecked } : {}), confirmed: true });
        },
        deny() { const t = this.data.target; if (t?.stage === 'decision' && !this.data.busy && !this.data.uncertain)
            this.triggerEvent('deny', { ...t, confirmed: true }); },
        close() { if (!this.data.busy) {
            identities.delete(this);
            this.setData({ checked: [] });
            this.triggerEvent('close');
        } },
    }
});
