"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./shared/client");
const journal_1 = require("./shared/journal");
const login_broker_1 = require("./shared/login-broker");
// Host/account setup supplies the reviewed HTTPS ingress and login broker.
// No model key, Connector credential or enterprise membership is in this app.
// Native notification identity comes from original login recipientBindings.
// Popup decisions are authenticated client reports, never signed platform proof.
// notificationBinding is only a legacy read boundary; no identity is entered here.
const baseUrl = ''; // Set only to the deployment's reviewed HTTPS native ingress.
const client = new client_1.WorkspaceClient(wx, { baseUrl, goalMode: 'muse', journal: (0, journal_1.fileJournal)(wx), loginBroker: baseUrl ? (0, login_broker_1.createWechatLoginBroker)(wx, baseUrl) : undefined });
App({ globalData: { client }, onHide() { } });
