"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validPublication = validPublication;
exports.canReviewDraftRepair = canReviewDraftRepair;
exports.mediaSnapshotText = mediaSnapshotText;
exports.publicationScopeText = publicationScopeText;
exports.presentPublication = presentPublication;
const hash = (value) => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
const phases = ['preparing', 'pending_approval', 'approved', 'denied', 'stale', 'running', 'partial', 'uncertain', 'succeeded', 'blocked'];
function validPublication(value, cid, sid) {
    return value && value.id === value.scope?.operationId && value.action === value.scope.action && value.scope.conversationId === cid && value.scope.serviceId === sid && Number.isInteger(value.scope.serviceRevision) && hash(value.scopeHash) && hash(value.scope.previewHash) && phases.includes(value.status) &&
        Array.isArray(value.steps) && Array.isArray(value.scope.transfer?.images) && value.automaticRetry === false && typeof value.canExecute === 'boolean' && typeof value.canReconcile === 'boolean' && typeof value.stale === 'boolean' &&
        ['draft', 'publish', 'repair_draft'].includes(value.action) && (!value.receipt?.mediaEvidence || value.receipt.mediaEvidence.remoteBytesVerified === false) &&
        (value.action !== 'repair_draft' || !!value.scope.draftOperationId && hash(value.scope.draftScopeHash) && hash(value.scope.repair?.beforeRemoteContentHash) && hash(value.scope.repair?.repairBasisHash) && Array.isArray(value.scope.repair?.steps) && value.scope.repair.steps.every(step => step === 'retail_variant') && typeof value.scope.repair.approveObservedMedia === 'boolean' && Array.isArray(value.scope.repair.mediaSnapshot));
}
function canReviewDraftRepair(value) { return value.action === 'draft' && value.status === 'partial' && !value.stale && value.reconciliationSource === 'read_only_shopify_reconciliation' && value.receipt?.found === true && value.receipt.productStatus === 'DRAFT' && hash(value.receipt.remoteContentHash); }
function mediaSnapshotText(media) { return media.map(item => `${item.id}\n${item.mediaContentType} · ${item.status}\nalt ${item.alt ?? '未提供'}\nURL ${item.imageUrl ?? '未提供'}`).join('\n\n') || '未提供远端媒体快照'; }
const issueNames = { media_identity_unconfirmed: '原媒体身份未确认', product_content_changed: '商品文字与审阅范围不符', retail_variant_changed: '零售变体/售价未匹配', media_not_ready: '原媒体尚未 READY', remote_content_changed: '远端内容或图片地址已变', product_status_changed: '商品状态已变', publication_marker_changed: '原渠道发布标记未匹配', publication_not_acknowledged: '精确渠道尚未确认发布' };
function publicationScopeText(scope) {
    const preview = scope.preview, images = scope.transfer.images;
    if (scope.action === 'repair_draft') {
        const repair = scope.repair;
        return `修复这一已对账的原 DRAFT；不创建商品、不上传图片、不激活或发布\n店铺 ${scope.shopDomain} · ${scope.shopId}\n原服务 ${scope.serviceId} · 修订 ${scope.serviceRevision}\n原草稿操作 ${scope.draftOperationId}\n原草稿 scope SHA256 ${scope.draftScopeHash}\n原商品 ${scope.productId} · 原变体 ${scope.variantIds.join('、')}\n缺失步骤 ${repair.steps.length ? '仅 retail_variant：设置审阅的零售售价/变体' : '没有变体写入，仅核对所审批媒体身份'}\n标题 ${preview.product.title}\nSKU ${preview.variants.map(item => item.sku || '未提供').join('、')} · 消费售价 ${preview.saleUnit.consumerPrice} ${preview.market.currency}\n${preview.display.paragraphs.join('\n')}\n原预览 SHA256 ${scope.previewHash}\n修复前远端内容 SHA256 ${repair.beforeRemoteContentHash}\n修复依据 SHA256 ${repair.repairBasisHash}\n原创建回执 ${repair.originalCreateStatus}\n${repair.approveObservedMedia ? '本范围另行批准采用以下观察到的既有媒体身份' : '保留原已确认媒体身份'}：\n${mediaSnapshotText(repair.mediaSnapshot)}\n原已选图片/上传证据：\n${images.map(image => image.kind === 'artifact' ? `${image.asset.artifactId} v${image.asset.version} · SHA256 ${image.asset.sha256}` : image.url).join('\n')}\n不重新传输图片；远端身份/READY 不等于 CDN 字节一致，remoteBytesVerified=false。`;
    }
    return `${scope.action === 'draft' ? '创建一个 Shopify DRAFT，仅上传以下已选图片；本次不发布渠道' : '发布已核对的原草稿到这一个精确渠道'}\n店铺 ${scope.shopDomain} · ${scope.shopId}\n原服务 ${scope.serviceId} · 修订 ${scope.serviceRevision}\n商品 ${scope.productId || '待创建原草稿'} · 渠道 ${scope.publicationId || '本次没有渠道发布'}\n标题 ${preview.product.title}\n消费售价 ${preview.saleUnit.consumerPrice} ${preview.market.currency} · ${preview.saleUnit.unitsPerPack} ${preview.saleUnit.unit}/包\n${preview.display.paragraphs.join('\n')}\nSKU ${preview.variants.map(item => item.sku || '未提供').join('、')}\n本次图片：\n${images.map(image => image.kind === 'artifact' ? `${image.sourceNote}\n原文件 ${image.asset.artifactId} v${image.asset.version}\nSHA256 ${image.asset.sha256}` : `${image.sourceNote}\n公开 URL ${image.url}（不具有原始字节 SHA）`).join('\n\n') || '没有图片'}\n预览 SHA256 ${scope.previewHash}\n图片远端 READY/上传回执不等于 CDN 转码字节一致；remoteBytesVerified=false。`;
}
function presentPublication(value) {
    const r = value.receipt, complete = value.status === 'succeeded' && r?.complete === true;
    const published = complete && value.action === 'publish' && r?.published === true && r.publicationId === value.scope.publicationId && value.businessCompletion === 'published';
    const title = value.stale ? published ? '历史渠道发布回执，当前范围已变' : complete && value.action !== 'publish' ? '历史草稿回执，当前范围已变' : '原审阅范围已失效' : published ? '精确渠道发布已核对' : complete && value.action !== 'publish' ? value.action === 'repair_draft' ? '原草稿修复已核对，尚未发布' : 'Shopify 原草稿已核对，尚未发布' : { preparing: '正在准备原写入审批', pending_approval: '等待明确批准或拒绝', approved: '已批准，等待独立执行', denied: '原写入审批已拒绝', stale: '原审阅范围已失效', running: '原操作处理中，以回执为准', partial: '原商品部分完成，禁止自动补写', uncertain: '原结果未知，只能读取核对', blocked: '原写入操作受阻' }[value.status] || '原回执待核对';
    const labels = { product_create: '创建原草稿', retail_variant: '设置审阅售价/变体', retail_variant_repair: '仅补原缺失零售变体', activate_product: '激活已核对原草稿', publish_product: '精确渠道发布' };
    return { ...value, title, scopeDetail: publicationScopeText(value.scope),
        detail: `${value.scope.shopDomain}\n${r?.productId || value.scope.productId || '尚无确认的 Shopify 商品 ID'}\n渠道 ${value.scope.publicationId || '本次仅草稿'}\n${value.steps.map(step => `${labels[step.step] || (/^image_\d+_stage$/.test(step.step) ? '准备原图片上传' : /^image_\d+_upload$/.test(step.step) ? '上传已选原图片' : step.step)} · ${step.status === 'acknowledged' ? '收到原回执' : step.status === 'started' ? '已记录意图，结果待核对' : step.status}`).join('\n')}\n${(r?.issues || []).map(issue => issueNames[issue] || issue).join('；')}${value.error ? '\n' + (value.error.message || value.error.code) : ''}${value.stale ? '\n此历史操作范围已过期，不可执行。' : ''}`,
        repair: canReviewDraftRepair(value), mediaNote: r?.mediaEvidence ? '媒体原身份/READY以原回执为准；CDN转码字节未核验（remoteBytesVerified=false）。' : '原始文件 SHA 与远端媒体结果分别核对。',
        timeNote: published ? `所选渠道发布时间 ${r?.publishedAt || '未提供，不能作为监测起点'}${r?.onlineStorePublishedAt ? '\n独立在线商店时间 ' + r.onlineStorePublishedAt : ''}` : '',
        decide: value.status === 'pending_approval' && value.approvalStatus === 'pending', execute: value.canExecute && !value.stale, reconcile: value.canReconcile && value.status !== 'running', published };
}
