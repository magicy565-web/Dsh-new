"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.supplierErrorText = void 0;
exports.validSupplier = validSupplier;
exports.validSupplierSample = validSupplierSample;
exports.presentSupplier = presentSupplier;
exports.trafficText = trafficText;
exports.sampleText = sampleText;
exports.presentMonitor = presentMonitor;
const notification_1 = require("./notification");
const supplier_view_1 = require("./supplier-view");
function validSupplier(value, cid) {
    return value && value.id === value.serviceId && value.conversationId === cid && Number.isInteger(value.revision) && value.revision > 0 && /^[a-f0-9]{64}$/.test(value.profileHash) && value.profile && Array.isArray(value.profile.images) &&
        ['pending', 'needs_information', 'preview_ready', 'blocked', 'failed', 'interrupted', 'cancelled', 'rejected'].includes(value.phase) && Array.isArray(value.questions) && value.questions.every(item => typeof item.field === 'string' && typeof item.question === 'string') && Array.isArray(value.suggestions) &&
        (!value.preview || value.preview.revision <= value.revision && value.preview.profileHash === value.profileHash && /^[a-f0-9]{64}$/.test(value.preview.previewHash) && value.preview.contentHash === value.preview.previewHash && value.preview.externalStatus === 'preview' && value.preview.published === false);
}
function validSupplierSample(sample) { const t = sample?.traffic; if (!t || !('contractVersion' in t))
    return true; const count = t.metrics?.productDetailViews?.value; return t.contractVersion === 2 && ['partial', 'unavailable', 'unconfigured', 'unsupported', 'no_data'].includes(t.status) && t.metrics?.sessions?.value === null && t.metrics.sessions.status === 'unsupported' && t.complete === false && t.freshness === 'unknown' && t.dataLagSeconds === null && typeof t.completePagination === 'boolean' && t.source?.kind === 'ga4_data_api_v1beta' && (count === null || Number.isSafeInteger(count) && count >= 0 && t.status === 'partial' && t.completePagination && !!t.coverage); }
const show = (value) => value === null || value === undefined ? '未知' : String(value);
const supplierErrorText = (code) => ({ NOTIFICATION_SCOPE_CHANGED: '原监测、总结或通知范围已变，请重新读取后审阅', NOTIFICATION_SUBSCRIPTION_REQUIRED: '缺已绑定原登录的一次性客户端报告；不是独立微信授权证明', NOTIFICATION_SUBSCRIPTION_PROVIDER_REQUIRED: '缺可信原生订阅设施，未调用微信订阅或发送', NOTIFICATION_NATIVE_HOST_REQUIRED: '既有宿主未接可信收件人引用读取/原生订阅；禁止自报OpenID授权', NOTIFICATION_CONNECTOR_REQUIRED: '原通知 Connector 尚未启用，客户端不会开启或扩权', NOTIFICATION_UNCONFIGURED: '七天总结通知未配置/未启用，尚未发送', NOTIFICATION_ALREADY_ATTEMPTED: '原通知已交接或取消，保留原回执，不再发送', NOTIFICATION_SUMMARY_CHANGED: '准确七天总结已改变，请重新审阅原哈希和修订', NOTIFICATION_NATIVE_REQUEST_FAILED: '微信原生订阅未完成，没有记录accept或通知授权', SUPPLIER_REPAIR_CONNECTOR_REVIEW_REQUIRED: '原 Connector 尚未单独授权 repair_draft；请由负责人审阅配置，客户端不会扩权', SHOPIFY_REPAIR_RECONCILIATION_REQUIRED: '先只读核对准确原草稿，再单独审阅修复', SHOPIFY_REPAIR_MEDIA_REVIEW_REQUIRED: '原媒体身份需要另行确认；已确认媒体不能换成观察到的其他 ID', SHOPIFY_REPAIR_MEDIA_TRANSFER_UNCONFIRMED: '原图片上传证据未确认，不能补传或修复', SHOPIFY_REPAIR_MEDIA_OR_CONTENT_CHANGED: '媒体或公开内容已改变，不能用缺失步骤修复覆盖', SHOPIFY_REPAIR_VARIANT_ALREADY_ACKNOWLEDGED: '零售变体已收到原回执，不能再次补写', SHOPIFY_REPAIR_PUBLICATION_PRESENT: '商品已激活或已有发布执行，不能作为草稿修复', SHOPIFY_REPAIR_STALE: '原草稿、媒体或修复范围已变，请只读核对后重新审阅', SHOPIFY_REPAIR_NOT_REQUIRED: '完整原草稿不需要缺失步骤修复', SUPPLIER_PUBLICATION_PENDING: '准确原商品仍有未完成或未知操作，先只读核对', SHOPIFY_SETUP_REQUIRED: 'Shopify 尚未配置；没有创建或发布商品', SHOPIFY_PRODUCT_WRITE_NOT_AUTHORIZED: 'Shopify 商品写入尚未授权；没有创建或发布', SUPPLIER_SAVE_PENDING: '原产品保存回执待服务端核对；没有另建产品', SUPPLIER_REVISION_CONFLICT: '原商品修订已改变，请重新读取后审阅', SUPPLIER_MONITOR_START_REQUIRED: '需要明确的 UTC 开始时间', SUPPLIER_PUBLICATION_TIME_REQUIRED: '没有可用的已核验在线商店发布时间', SUPPLIER_IMAGE_UNAVAILABLE: '原图片版本或 SHA 无法核对' }[code] || code);
exports.supplierErrorText = supplierErrorText;
function presentSupplier(value) {
    const p = value.profile;
    return { id: value.id, revision: value.revision, phase: value.phase, title: p.name || '正在整理商品事实', preview: value.preview,
        detail: `销售国家 ${show(p.targetMarket)} · 消费售价 ${show(p.consumerPrice)} ${show(p.currency)}\n零售 ${show(p.unitsPerPack)} ${show(p.retailUnit)} / 包\n内部供货：MOQ ${show(p.supplierMoq)} ${show(p.supplierUnit)} · 批发 ${show(p.wholesaleUnitPrice)} ${show(p.wholesaleCurrency)} · 生产 ${show(p.productionDays)} 天`,
        questions: value.questions.slice(0, 3).map(item => item.question.replace(item.field, supplier_view_1.supplierFieldLabels[item.field] || item.field)), extraQuestions: Math.max(0, value.questions.length - 3),
        suggestions: value.suggestions.map(item => `${supplier_view_1.supplierFieldLabels[item.field] || item.field}：${show(item.value)}（未确认建议）`),
        status: { pending: 'Pi 正在保存商品事实', needs_information: '商品事实已保存，等待必要信息或预览范围', preview_ready: '原服务预览已就绪', blocked: '原服务阻挡', failed: '原整理未完成', interrupted: '原整理中断', cancelled: '原整理已取消', rejected: '原服务已拒绝' }[value.phase],
        external: value.external?.published === true && value.externalStatus === 'published' ? `已观察到实际发布 · ${value.external.productId}` : value.externalStatus === 'shopify_draft' ? `已观察到 Shopify 草稿 · ${value.external?.productId}` : value.externalStatus === 'unpublished' ? `实际商品尚未发布（${value.external?.productStatus || '状态未知'}）` : '尚未创建或发布到 Shopify',
        product: value.productReference ? `原资料库产品 ${value.productReference.productId} · 修订 ${value.productReference.productRevision}` : '', editable: !['pending', 'cancelled', 'rejected'].includes(value.phase), error: value.error?.message || (value.error ? (0, exports.supplierErrorText)(value.error.code) : '') };
}
function trafficText(sample) {
    const traffic = sample.traffic;
    if (traffic && 'contractVersion' in traffic && traffic.contractVersion === 2) {
        const count = traffic.metrics.productDetailViews.value;
        return `商品详情浏览事件 ${count === null ? '不可用，未按零处理' : count + '（临时观察）'} · ${traffic.status}\nsessions 不可用；不把重复商品浏览事件标为访客、销量或会话数，不计算商品转化率。\n来源 ${JSON.stringify(traffic.source)}\n请求窗口 ${JSON.stringify(traffic.requestedWindow)}\n实际覆盖 ${traffic.coverage ? traffic.coverage.from + ' 至 ' + traffic.coverage.to : '未确认'} · 粒度 ${traffic.granularity || '未知'}\n流量采样 ${traffic.sampledAt} · 新鲜度 ${traffic.freshness} · 延迟未知\n分页 ${traffic.completePagination ? '完整' : '不完整'} · 七天摄取完整性未确认（complete=false）\n采样说明 ${JSON.stringify(traffic.sampling)}\n质量 ${JSON.stringify(traffic.quality)}\n指标定义 ${JSON.stringify(traffic.metricDefinitions)}\n原错误 ${JSON.stringify(traffic.error)}`;
    }
    return traffic && 'sessions' in traffic && ['available', 'partial'].includes(sample.trafficStatus) ? `产品 sessions ${show(traffic.sessions)} · ${sample.trafficStatus === 'partial' ? '覆盖不完整' : '原来源可用'}` : `产品流量 ${sample.trafficStatus === 'unsupported' ? '当前来源不支持产品归因' : '不可用，未按零处理'}`;
}
function sampleText(sample) {
    if (!sample)
        return '尚未读取销量与产品流量；缺数不能当作零。';
    return `${sample.salesStatus === 'available' && sample.sales ? `保留销量 ${show(sample.sales.retainedUnits)}；原下单 ${show(sample.sales.grossUnits)}，取消 ${show(sample.sales.cancelledUnits)}，退款 ${show(sample.sales.refundedUnits)}（可重叠，不重复扣减）` : '销量不可用，未按零处理'}\n${trafficText(sample)}\n采样 ${sample.sampledAt}\n覆盖 ${sample.coverage.from} 至 ${sample.coverage.to}\n延迟 ${sample.dataLagSeconds === null ? '未知' : sample.dataLagSeconds + ' 秒'} · 分页 ${sample.completePagination === undefined ? '总结未提供，见原采样' : sample.completePagination ? '完整' : '不完整'}\n数据源 ${sample.source || '总结未提供，见原采样'}\n${sample.errors.map(item => (0, exports.supplierErrorText)(item.code)).join('；')}`;
}
function presentMonitor(value) {
    const n = (0, notification_1.notificationText)(value.notification), t = value.latestSample?.traffic;
    return { ...value, notificationTitle: n.title, notificationDetail: n.detail, firstNotificationDetail: (0, notification_1.notificationText)(value.firstNotification).detail, sampleHeadline: value.latestSample ? `销量 ${value.latestSample.sales?.retainedUnits ?? '不可用'} · ${t && 'contractVersion' in t ? '商品详情浏览事件 ' + (t.metrics.productDetailViews.value ?? '不可用') + ' · ' + t.status + ' · sessions不可用' : '产品流量见原来源'}` : '尚未采集，缺数不当零', detail: `${value.scope.productId}\n变体 ${value.scope.variantIds.length ? value.scope.variantIds.join('、') : '产品全部变体（原范围）'}\n开始依据 ${value.scope.startSource === 'verified_online_store_publication' ? '已核验在线商店发布时间' : '用户明确 UTC 时间'}\n${value.scope.startAt} 至 ${value.scope.endAt}\n${value.scheduleEnabled ? '原 Schedule 已启用，以服务端执行记录为准' : '配置尚未启用，需要原 Schedule 明确审批'}\n${value.stoppedAt ? '已停止原监测' : '状态 ' + value.status}\n${sampleText(value.latestSample)}\n${n.title}`,
        summaryText: value.summary ? `原会话总结已保存 · 修订 ${value.summary.revision}${value.summary.corrected ? ' · 已更正同一消息' : ''}${value.summary.provisional ? ' · 数据未齐，等待原来源更正' : ''}\n${n.title}；后续更正复用原消息，不追加推送。` : '' };
}
