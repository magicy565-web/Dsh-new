# Unified development integration after the 18:56 checkpoint

The fixed `65252e2` source/import packages remain an immutable checkpoint. Small later fixes are committed/pushed with tests, without regenerating large archives. The final unified source/import package will be generated after the independent TUI and supplier MCP fixed commits are integrated and validated.

## Original notification cold recovery

Reproduced on the original compiled Page/Client, signed local HTTP and persisted original Store: create two distinct supplier products, execute one separately approved first-sample or seven-day notification for the older product, lose its local acknowledgement, then restart server/client and enter directly through `onShow`. The page had no supplier mode and selected the newer product because only `supplier-*` and `publication-*` pending requests restored the business context; notification pending labels were also missing.

Minimal fix: treat the existing `notification-*` journal kinds as supplier business recovery, restore the existing `pendingSupplierId`, and label the original pending notification operation. No change to sender, consent, approval, native subscription, request journal, role or backend semantics. The new tests cover both notification phases and duplicate retry clicks, verify the original monitor/operation/request body, and require exactly one provider attempt, one native popup and no second monitor. Unknown delivery stays unknown.

Validation: `npm run build:mini` passed; `node --test miniprogram/test/business-recovery-regressions.test.mjs miniprogram/test/notification-closure-client.test.mjs miniprogram/test/publication-client.test.mjs miniprogram/test/lifecycle.test.mjs` passed 36/36. Reproduction failed before the two-line page change on both notification phases. Local transport/provider fixtures only; no live WeChat/Muse/Shopify proof.

Further integration remains in progress. No main merge, force push, production/deployment, payment or credential/permission creation.

## Pi TUI integration

Cherry-picked the independently handed-off commits `533a2ab759f8208c3b3300ae7f4e91342eab0ff1`, then `0fbdeb04e0a5ae00755163b8ed81e8c741c7ab70` in order. Integrated commits are `59f2b6f` and `2ce3efc`; all TUI files and the isolated dependency lock remain under `tui/`, without changing root dependencies or the existing backend execution kernel.

Reverified on the unified branch: exact README `npm --prefix tui ci` and `npm --prefix tui start -- --version` (private temporary data directory) return Pi coding-agent 1.1.0; TUI tests 5/5; actual installed Pi CLI/PTY keyboard-and-confirmation smoke has seven checks including the unchanged Python consumer's same-task claim/heartbeat/upload/submit and cold TUI readback; original Pi/Muse binding/policy tests 3/3; consumer offline tests 40/40. Model runs remain zero in the local transport fixture. Earlier installation with `--ignore-scripts` also worked; the documented normal install was then checked separately.

No existing live owner transport, remote Muse installation/version/egress, actual owner login, real external task claim/return or production authority was supplied. Passing actual Pi TUI runtime does not prove those missing integrations. Windows/PowerShell remains unverified.

Additional original draft approval/rejection response-loss tests pass for both decisions: cold restore replays the exact original request and scope, one operation/approval remains, zero Shopify creates/uploads; duplicate retry clicks cause one replay. `business-recovery-regressions.test.mjs` now reports 6/6 including nested phase/decision cases.

## GitHub CI observations (commit-specific)

Parent's read-only check: packaging head `d4612de0c251039898b0f1c59824d5721e447f99` has runs 38292607838 and 38292535772, both startup_failure with zero jobs. Earlier 38284242811 is historical. This agent read the original workflow API for integrated TUI head `2ce3efc85cad8e7af670ca9d7c3088399f4e3cde`: PR-triggered run 38293253100 is completed/startup_failure; jobs API returned an empty list. None is a passing CI run. No rerun, billing, repository settings or workflow changes were made.

## Supplier owner MCP / GA4 integration

Consumed PR57's published fixed sequence `00c0920f0d1b387a3ba9571aba74ddec4868f548`, `4fc6b9677978d5a2cb4b1c0f142203d61cdff46a`, `8efb14e6bfe05d766eed26014e383c89d7b3c84f` in order, integrated as `3fc7a5b`, `d91987f`, `be7419c`. Original role/session/body checks and host-supplied existing grant resolution remain required. The 15 closed tools cannot decide publication approvals, activate schedules or subscribe/send notifications. Ordinary CLI without the original resolver still reports `SUPPLIER_OWNER_BINDING_REQUIRED`; metadata/configuration is not a verified GA4 connection. Shared `server/index.mjs` uses only the producer's small imports/options/route wiring; no root lockfile change.

Unified build and mini build passed. Actual combined backend run: 684 tests, 677 passed, 7 original conditional skips, 0 failures. Actual combined mini plus original protocol run: 118/118. Original owner MCP HTTP transport and ordinary GA4 child-process CLI checks: 10/10. Integrated TUI tests 5/5 and actual Pi CLI/PTY seven checks passed again. Counts overlap; do not add them or claim remote account/GA4/Muse acceptance.

## In-flight response across an account change

Two failures were reproduced with the compiled original client and actual signed enterprise HTTP, using distinct existing fixture members: delayed old-owner conversation creation response was accepted into the next owner's checkpoint; a delayed 401 from the already revoked old session cleared the new session. The transport driver delays actual server responses rather than fabricating a new identity or business result.

Minimal repair in `shared/client.ts`: pin response acceptance to its requesting owner; clear authentication only when the rejected request's original in-memory session and token still match; prevent an old mutation rejection from editing the new owner's journal. Old-owner write-ahead data remains available. After signing into the original owner again, the exact admitted creation request reconciles to its original server-created conversation without another POST. No service/backend policy changed.

`account-race-http.test.mjs` covers both failures and real subsequent owner/original-request recovery. Targeted account/business/lifecycle run: 24/24 passed. Both new checks failed before the matching guard changes. Full combined regression will be rerun on the final fixed source after the remaining TUI host patch is integrated.

## File completion after account switching

Extended the same signed-HTTP reproduction to native file callbacks. Before the fix, an original owner's delayed local file read could upload its bytes using the next session; delayed download or SHA completion could return the old file path; an actual owner-only supplier image with correct SHA also returned after switching; and a delayed UTF-8 preview callback repopulated the new page after its account content was cleared.

The client now checks the requesting owner after local read, native download and digest callbacks, including the original supplier image route. The existing Page file handler checks its epoch/subject before native preview and after text read. SHA validation remains mandatory and unchanged. The MCP test fixture now exposes the raw bytes it actually received so image verification uses the real HTTP PNG bytes, not a guessed/recreated file. No production service, auth or upload policy changed.

Account-race, original supplier HTTP, lifecycle and owner MCP transport tests passed 37/37. Files use actual server-created IDs, exact versions and SHA values. All new file boundary cases reproduced failures before the added checks; only local enterprise members/storage/transports are exercised.

The newer TUI Host patch `959c44dad9fa6855962f43429e865ec00029f36f` was integrated as `33d45de`. On that combination, mini plus original protocol tests passed 120/120, TUI tests 7/7 and real Pi PTY seven checks passed. The next producer handoff also changes original `server/wechat-ingress.mjs`; it will be integrated separately and the combined checks updated rather than claiming prior results apply to it.

## Original ingress launcher / exact Muse handoff

Consumed fixed `cc49bc9fd017710e2f948d0cdfa220c1a6a638a5` after `959c44d`; integrated as `7289e54`. The change exposes a host-internal original ingress launcher, not a new public login route or automatic login side effect, and creates a local public handoff only for an already approved/dispatched exact original order. It does not send the file or claim a task. Real production foreground mounting, browser SSO handoff and remote Muse remain unverified.

On the actual `7289e54` combination: original builds passed; full backend 684 total, 677 passed, 7 original conditional skips, 0 failed; mini/original protocol 126/126; TUI 9/9; actual Pi PTY eight checks; original ingress/Muse regressions 7/7. The original Python consumer remains unchanged.

The publication browser driver's first run completed all nine business assertions then failed during cleanup because `onUnload` clearing readiness triggered a queued render after the browser closed. The driver now drains its render queue before closing; notification cleanup has the same fix. Reentry verification clears only the fixture's local publication cache before waiting for the actual original server operation to be reread. Test assertions were retained. Retest exited 0 for publication and first-notification flows, with no page errors, one fixture publication and one fixture provider attempt respectively. They remain limited Chromium/native-callback/local HTTP evidence.

Browser outputs now default to separate untracked runtime evidence directories (or an explicit output argument). Old tracked historical screenshots/checkpoint packages are preserved. Runtime records use the actual source HEAD instead of hard-coded historical backend IDs and label the one faux model call as synthetic. Final same-source screenshots will be rerun on the frozen committed source.

## Latest signed-session MCP fixed sequence and combined run

Consumed additional PR57 commits `d5bc67bc2a068ca61622e94b3880db5cfef348d4`, `fb7651050ac7bc1a1fd9d1a13d89f2dfc3bec29b`, `8af564f15fcb821cde1054984356d2e3f3c75c0c`, `68558d22a46e92fef4b8a300c69b2fbad61fbb20` in that order; integrated as `e9adea2`, `ce59d7b`, `e1b42a5`, `50f8ce2`. The one conflict was in the HTTP test fixture: retained both actual binary response bytes and the producer's request timeout. Business/server code had no conflict.

The new `/supplier-session-mcp` facet reuses the original signed HTTP owner session and its exact method/target/body/CSRF/expiry/conversation/privacy checks. It creates no grant and does not fall back from the external `/supplier-mcp` facet, which still needs its original reviewed scope resolver. Tools still cannot decide publication approval, activate schedules or subscribe/send notifications.

On actual fixed `50f8ce24eb66f858168c5aac06cb28877bad11b8`: builds passed; full backend 706 total, 699 passed, 7 conditional skips, 0 failed; mini/original protocol 126/126; TUI 9/9 and actual Muse PTY eight checks; owner/session MCP plus account-race targeted 26/26. Producer PR57's recorded backend result is 703 total, 696 passed, 7 skips; the combined root test files differ only by the added three readiness tests and the binary-capable fixture. Earlier 677 passed belonged to the pre-session `7289e54` combination and is not asserted for this newer source.

Read-only GitHub workflow metadata for `50f8ce2`: run 38297574549 completed with startup_failure; jobs API returned []. This is not passing CI. No rerun, setting/billing or paid action.

## Same Pi TUI supplier session tools

Consumed `516c15f5029125ff4e8b307862ef4c00567edec4` after PR57's latest sequence and TUI `cc49bc9`; integrated as `18e3b07aa6a1297e5258a55e83e2fb8af9c48d05`. Only `tui/` changed from `50f8ce2`; root server/tests/client source are identical. One existing Pi extension/Host transport now registers `/workspace-supplier` command access to 15 original session tools. Raw image review is represented by byte length and SHA, and native RPC is bounded to accommodate the original image schema. No extra owner authorization or model tool registration.

Actual reruns on `18e3b07`: supplier HTTP integration 3/3; supplier Pi PTY seven checks, including >32KiB actual image transfer, exact consumer-sale-unit preview and backend/Pi cold restore; existing TUI tests 9/9 and original Muse Pi PTY eight checks. Publication browser nine path checks and first-notification browser ten path checks both exited 0 with no page errors. Small source-labelled screenshots plus the observed original cleanup error record are in `integration-checkpoints/18e3b07/`.

Plain language currently displays help; `modelToolsRegistered:false` is intentional and not described as autonomous model/agent tool selection. Real production host enablement, browser SSO foreground launch, real remote Muse/Shopify/GA4/WeChat and continuous seven-day outcomes remain unverified. The 18:56 packages are preserved; no new large archive was generated for these small commits.

Execution environment restoration was verified with an actual exit-0 `git status`, `git rev-parse HEAD`, and Node 24.19.0 command, not a connection-status label.
