当前小程序导入包：源提交65252e24f4b467f32d77f8dd755168e5a04b2be5，后端e60f1a8bf873fce4ba0b5c90c313d8a6e9474fea。
解压后在微信开发者工具选择含project.config.json的本目录。使用原会话/精灵/素材，含原draft/publish/repair、商品事件流量、七天与独立首次采样通知，以及原会话只读店铺就绪核验。
本包不是旧20:30/v2包。BUILD-MANIFEST.json逐文件SHA应与同源干净build:mini输出一致。
appid=touristappid，urlCheck=true，baseUrl为空；无实际账号/企业授权时清晰阻挡，不生成假身份。需负责人配置既有AppID、受信loginBroker/baseUrl/合法域名及原权限；不能只登录商店就声称服务端就绪。
客户端不带server、node_modules、测试、私有配置、token或OpenID。wx原生弹窗决定仅客户端报告，平台授权待发送核验。
真实WeChat工具/真机/审核、实际Shopify/GA4/通知/连续七天未通过；当前截图是原源文件Chromium与本地HTTP/callback fixture。
