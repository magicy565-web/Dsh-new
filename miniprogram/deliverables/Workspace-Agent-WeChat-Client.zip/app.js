"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./shared/client");
const journal_1 = require("./shared/journal");
// Host/account setup supplies the reviewed HTTPS ingress and login broker.
// No model key, Connector credential or enterprise membership is in this app.
const client = new client_1.WorkspaceClient(wx, { baseUrl: '', journal: (0, journal_1.fileJournal)(wx) });
App({ globalData: { client }, onHide() { } });
