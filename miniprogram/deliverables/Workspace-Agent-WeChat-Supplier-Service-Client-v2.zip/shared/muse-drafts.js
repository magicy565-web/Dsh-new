"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validMuseDraft = validMuseDraft;
exports.presentMuseDraft = presentMuseDraft;
const muse_draft_view_1 = require("./muse-draft-view");
const phases = ['pending', 'needs_information', 'ready_for_review', 'preparing', 'prepared', 'rejecting', 'rejected', 'failed', 'blocked'];
function validMuseDraft(value, conversationId) {
    return value && typeof value.id === 'string' && value.conversationId === conversationId && Number.isInteger(value.revision) && value.revision > 0 && phases.includes(value.phase) &&
        (value.draftHash === null || /^[a-f0-9]{64}$/.test(value.draftHash)) && value.scope && value.scope.publicDataConfirmed === false && Array.isArray(value.questions) &&
        value.questions.every(item => typeof item.field === 'string' && typeof item.question === 'string') && Array.isArray(value.missingFields) && typeof value.publicText === 'string' && Array.isArray(value.suggestions) && value.executionStarted === false && value.wakeVerified === false;
}
function presentMuseDraft(value) {
    const phase = value.phase;
    const view = (0, muse_draft_view_1.draftPresentation)({ id: value.id, conversationId: value.conversationId, revision: value.revision, draftHash: value.draftHash, phase,
        scope: { ...(value.scope.serviceId !== null ? { serviceId: value.scope.serviceId } : {}), ...(value.scope.product !== null ? { product: value.scope.product } : {}), ...(value.scope.market !== null ? { market: value.scope.market } : {}), ...(value.scope.objective !== null ? { objective: value.scope.objective } : {}), ...(value.scope.budgetCredits !== null ? { budgetCredits: value.scope.budgetCredits } : {}), ...(value.scope.deadlineAt !== null ? { deadlineAt: value.scope.deadlineAt } : {}) },
        questions: value.questions.map(item => item.question), publicText: value.publicText, suggestions: value.suggestions.map(item => `${item.label} · ${String(item.value)}`), ...(value.orderId ? { orderId: value.orderId } : {}) });
    const title = { pending: '正在整理委托草案', preparing: '正在核对原订单准备结果', rejecting: '正在核对原停止回执', rejected: '草案已拒绝', failed: '草案整理失败', blocked: '草案需要处理' }[value.phase];
    return { ...view, ...(title ? { title } : {}), phase: value.phase, detail: value.error?.message || '', editable: ['needs_information', 'ready_for_review', 'failed', 'blocked'].includes(value.phase), rejectable: ['pending', 'needs_information', 'ready_for_review', 'prepared', 'failed', 'blocked'].includes(value.phase) };
}
