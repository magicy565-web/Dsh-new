"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DraftReview = void 0;
exports.draftPresentation = draftPresentation;
function draftPresentation(value) {
    const summary = [value.scope.product, value.scope.market, value.scope.objective, value.scope.serviceId ? `服务 ${{ 'channel-validation': '渠道验证', 'buyer-discovery': '买家研究' }[value.scope.serviceId] || value.scope.serviceId}` : ''].filter(Boolean).join(' · ');
    return {
        ...value,
        title: value.phase === 'needs_information' ? '只需补充这些信息' : value.phase === 'prepared' ? '已关联原 Muse 订单' : value.phase === 'rejected' ? '此草案已拒绝' : '审阅委托草案',
        summary,
        budget: value.scope.budgetCredits === undefined ? '预算待明确' : `上限 ${value.scope.budgetCredits} credits`,
        deadline: value.scope.deadlineAt || '期限待明确',
        ready: typeof value.draftHash === 'string' && /^[a-f0-9]{64}$/.test(value.draftHash) && value.phase === 'ready_for_review' && value.questions.length === 0 && typeof value.scope.budgetCredits === 'number' && Number.isFinite(value.scope.budgetCredits) && value.scope.budgetCredits > 0 && Boolean(value.scope.deadlineAt),
    };
}
class DraftReview {
    constructor() {
        this.selected = null;
        this.budgetConfirmed = false;
        this.deadlineConfirmed = false;
        this.publicDataConfirmed = false;
    }
    open(value) { this.selected = JSON.parse(JSON.stringify(value)); this.budgetConfirmed = false; this.deadlineConfirmed = false; this.publicDataConfirmed = false; }
    close() { this.selected = null; this.budgetConfirmed = false; this.deadlineConfirmed = false; this.publicDataConfirmed = false; }
    confirm(values) { this.budgetConfirmed = values.includes('budget'); this.deadlineConfirmed = values.includes('deadline'); this.publicDataConfirmed = values.includes('public'); }
    get value() { return this.selected; }
    validate(current) {
        if (!this.selected || current.id !== this.selected.id || current.conversationId !== this.selected.conversationId || current.revision !== this.selected.revision || current.draftHash !== this.selected.draftHash || current.phase !== this.selected.phase) {
            this.close();
            throw new Error('草案范围已变更，请重新审阅当前版本。');
        }
        if (!draftPresentation(current).ready || !this.budgetConfirmed || !this.deadlineConfirmed || !this.publicDataConfirmed)
            throw new Error('请分别明确确认本次预算、期限与公开文字范围。');
        return { id: current.id, conversationId: current.conversationId, revision: current.revision, draftHash: current.draftHash };
    }
}
exports.DraftReview = DraftReview;
