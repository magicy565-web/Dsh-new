"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fileJournal = fileJournal;
function fileJournal(platform) {
    const fs = platform.getFileSystemManager();
    const location = (owner, baseUrl) => {
        // Full reversible namespace avoids hash collisions and filesystem name limits.
        const namespace = encodeURIComponent(JSON.stringify([baseUrl, owner]));
        const directory = `${platform.env.USER_DATA_PATH}/workspace-recovery/${namespace.match(/.{1,80}/g)?.join('/')}`;
        return { directory, path: `${directory}/checkpoint.json` };
    };
    return {
        read(owner, baseUrl) {
            if (!owner || !baseUrl)
                return null;
            const { path } = location(owner, baseUrl);
            try {
                return JSON.parse(String(fs.readFileSync(path, 'utf8')));
            }
            catch (error) {
                const detail = error instanceof Error ? error.message : error?.errMsg || String(error);
                if (/no such file|not found|ENOENT/i.test(detail))
                    return null;
                throw new Error('本机恢复记录无法读取，请先核对存储空间。');
            }
        },
        write(value) {
            const { directory, path } = location(value.owner, value.baseUrl);
            try {
                fs.mkdirSync(directory, true);
                fs.writeFileSync(`${path}.next`, JSON.stringify(value), 'utf8');
                fs.renameSync(`${path}.next`, path);
            }
            catch {
                throw new Error('本机恢复记录无法保存，请核对云端状态，避免新建重复操作。');
            }
        },
    };
}
