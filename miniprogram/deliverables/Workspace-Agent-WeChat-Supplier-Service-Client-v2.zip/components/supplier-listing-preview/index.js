"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const supplier_view_1 = require("../../shared/supplier-view");
Component({
    options: { styleIsolation: 'shared' },
    properties: {
        preview: { type: Object, value: null, observer(raw) {
                if (!raw) {
                    this.setData({ view: null, error: '' });
                    return;
                }
                try {
                    this.setData({ view: (0, supplier_view_1.presentSupplierPreview)(raw), error: '' });
                }
                catch (error) {
                    this.setData({ view: null, error: error instanceof Error ? error.message : '原商品预览无法读取。' });
                }
            } },
    },
    data: { view: null, error: '' },
});
