import path from 'node:path';
import { promises as fs } from 'node:fs';
import { createHash } from 'node:crypto';
import { Agent } from '@earendil-works/pi-agent-core';
import { Type, createModels, createProvider } from '@earendil-works/pi-ai';
import { openAICompletionsApi } from '@earendil-works/pi-ai/api/openai-completions.lazy';
import { createAssistantMessageEventStream } from '@earendil-works/pi-ai/utils/event-stream';
import { BACKGROUND_CONTEXT, withAbortSignal } from '@earendil-works/chord/context';
import { AssistantEntry, Harness, GenerationTask, ToolTask, createRegistry, defineDoc, defineExtension, defineTool, hook } from '@earendil-works/pi-durable';
import { openNodeJsonlStorage } from '@earendil-works/pi-durable/storage/jsonl/node';
import { ProviderError } from './provider.mjs';
import { SUPPLIER_FIELDS } from './supplier-profile.mjs';
import { normalizeSupplierProposal } from './supplier-draft.mjs';
import { capabilityPayloadHash } from './capabilities.mjs';
import { assertInputContextSnapshot } from './task-context.mjs';
import { openAIUsage, explicitPiUsage, requestAllowance, invocationUsage, PI_REQUEST_LIMIT } from './pi-usage.mjs';
import { MUSE_DRAFT_FIELDS, normalizeDraftProposal, assertDraftInvocation } from './muse-draft.mjs';

export const PI_SOURCE = 'abe508e1b89912adde45528136c3221eb69acdd7';
export const PI_VERSION = '1.1.0';
const context = BACKGROUND_CONTEXT;
const hash = value => createHash('sha256').update(value).digest('hex');
const RecordDoc = defineDoc({ kind: 'workspace.pi-invocations', version: 1, scope: 'conversation', history: 'latest', fork: 'initial', initial: () => ({ records: {}, active: null }) });
const POLICY = { version: 4, tools: ['workspace_input', 'workspace_propose_action', 'workspace_propose_muse_draft', 'workspace_propose_supplier_profile'], externalExecution: 'original-workspace-approval', replay: 'safe-only', storage: 'jsonl-fsync', budget: 'durable-request-reservations-wire-usage', museInput: 'original-owner-provenance', museDraft: 'quote-verified-inert-v1', supplier: 'quote-verified-private-v1' };
const fail = (code, message) => { throw new ProviderError(code, message); };
const clone = value => JSON.parse(JSON.stringify(value));

// Pi does not provide a process lock. This service may only open storage while
// the original Workspace Store holds the exclusive writer lease.
async function privateDirectory(directory) {
  await fs.mkdir(directory, { recursive: true, mode: 0o700 });
  const stat = await fs.lstat(directory);
  if (!stat.isDirectory() || stat.isSymbolicLink() || process.platform !== 'win32' && (stat.mode & 0o077)) fail('PI_STORAGE_UNSAFE', 'Pi storage requires a private regular directory.');
  for (const item of await fs.readdir(directory, { withFileTypes: true })) {
    const filename = path.join(directory, item.name);
    if (item.isSymbolicLink()) fail('PI_STORAGE_UNSAFE', 'Pi storage cannot contain symbolic links.');
    if (item.isDirectory()) await privateDirectory(filename);
    else if (!item.isFile()) fail('PI_STORAGE_UNSAFE', 'Pi storage contains an unsupported entry.');
    else if (process.platform !== 'win32') await fs.chmod(filename, 0o600);
  }
}

export function createPiProvider({ apiKey = '', model = 'gpt-6-sol', models: suppliedModels, providerId = 'workspace-fastaitoken', timeoutMs = 60_000 } = {}) {
  if (!/^[a-zA-Z0-9_.:/-]{1,160}$/.test(model)) throw new TypeError('Pi model must be a bounded server-configured model ID.');
  if (!Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 180_000) throw new TypeError('Invalid Pi timeout.');
  const models = suppliedModels || createModels();
  if (!suppliedModels) models.setProvider(createProvider({ id: providerId, name: 'Workspace reviewed FastAIToken', baseUrl: 'https://www.fastaitoken.com/v1',
    auth: { apiKey: { name: 'Host-managed FastAIToken key', resolve: async () => apiKey.trim() ? { auth: { apiKey } } : undefined } },
    models: [{ id: model, name: model, api: 'openai-completions', provider: providerId, baseUrl: 'https://www.fastaitoken.com/v1', reasoning: false, input: ['text'], cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }, contextWindow: 128000, maxTokens: 1600 }],
    api: openAICompletionsApi() }));
  const modelRef = models.getModel(providerId, model);
  const opened = new Map(), opening = new Map(), activeCalls = new Map();
  let store, directory, closing = false, closePromise;
  function assertActive(active) {
    if (closing || !active) fail('PI_NOT_ADMITTED', 'No active Workspace invocation authorizes this Pi operation.');
    const state = store.read(), run = state.runs.find(value => value.id === active.runId);
    if (!run || run.status !== 'running' || run.conversationId !== active.conversationId || run.executionHash !== active.executionHash || run.assistantId !== active.replyId)
      fail('PI_NOT_ADMITTED', 'The original Workspace run is stopped or its execution scope changed.');
    assertInputContextSnapshot(state, active.conversationId, run.inputContextSnapshot);
    assertDraftInvocation(state, run);
    if (run.supplierDraftContext) { const row = state.workspaceSupplierServices?.services.find(item => item.id === run.supplierDraftContext.serviceId); if (!row || row.cancelledAt || row.rejectedAt || row.revision !== run.supplierDraftContext.revision) fail('PI_NOT_ADMITTED', 'The original supplier intake was stopped or changed.'); }
    return run;
  }
  async function openConversation(conversationId) {
    if (opened.has(conversationId)) return opened.get(conversationId);
    if (opening.has(conversationId)) return opening.get(conversationId);
    const operation = (async () => {
      const location = path.join(directory, hash(conversationId));
      await privateDirectory(location);
      const storage = await openNodeJsonlStorage(location, context, { fsync: true });
      let harness;
      const state = { harness: null, root: null, active: null, location };
      const governedModels = new Proxy(models, { get(target, key) {
        if (key !== 'streamSimple') { const value = Reflect.get(target, key, target); return typeof value === 'function' ? value.bind(target) : value; }
        return (requested, transcript, options) => {
          const output = createAssistantMessageEventStream();
          void (async () => {
            let observed = null;
            try {
              assertActive(state.active);
              const requestId = state.active.requestId;
              const reservation = await state.root.commit(async tx => {
                const active = (await tx.doc(RecordDoc, state.root.id)).active;
                if (active.requestId !== requestId) fail('PI_NOT_ADMITTED', 'The Pi invocation changed before its model request.');
                const maxTokens = requestAllowance(active);
                if (!maxTokens) fail('TOKEN_BUDGET', 'Pi has no remaining admitted request/output allowance.');
                const index = active.requests.length;
                active.requests.push({ maxTokens, usage: null });
                return { index, maxTokens };
              }, context);
              assertActive(state.active);
              // Enforce at dispatch, after durable beforeRequest hooks and even
              // when their checkpoint captured earlier stream settings.
              const events = models.streamSimple(requested, transcript, { ...options, maxTokens: reservation.maxTokens, maxRetries: 0,
                onProviderStreamEvent: async (event, ref) => {
                  if (requested.api === 'openai-completions' && (event?.usage || event?.choices?.[0]?.usage)) observed = openAIUsage(event);
                  await options?.onProviderStreamEvent?.(event, ref);
                } });
              for await (const event of events) {
                if (event.type === 'done' || event.type === 'error') {
                  // The official faux provider is a keyless, explicitly supplied
                  // test transport with message-owned counters, not wire billing.
                  if (requested.api === 'faux') observed = explicitPiUsage((event.message || event.error)?.usage);
                  if (observed?.completionTokens > reservation.maxTokens) fail('OUTPUT_LIMIT', 'The provider exceeded this request output allowance.');
                  await state.root.commit(async tx => {
                    const active = (await tx.doc(RecordDoc, state.root.id)).active;
                    if (active.requestId !== requestId) fail('PI_NOT_ADMITTED', 'The Pi invocation changed before usage settlement.');
                    active.requests[reservation.index].usage = observed;
                  }, context);
                }
                output.push(event);
              }
              output.end(await events.result());
            } catch (error) {
              const message = { role: 'assistant', content: [], api: requested.api, provider: requested.provider, model: requested.id,
                timestamp: Date.now(), stopReason: 'error', errorMessage: error instanceof ProviderError ? error.message : 'Pi request reservation could not be verified.',
                usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 } } };
              output.push({ type: 'error', reason: 'error', error: message }); output.end();
            }
          })();
          return output;
        };
      } });
      const registry = createRegistry();
      const input = defineTool({ name: 'workspace_input', description: 'Read only an explicitly selected, verified input snapshot. No filesystem paths or ambient enterprise data.',
        parameters: Type.Object({ kind: Type.Union([Type.Literal('artifact'), Type.Literal('memory'), Type.Literal('skill')]), id: Type.String({ maxLength: 160 }) }), replay: 'safe',
        execute: async args => {
          const run = assertActive(state.active);
          const rows = state.active.snapshot?.[args.kind === 'artifact' ? 'artifacts' : args.kind === 'memory' ? 'memories' : 'skills'] || [];
          const item = rows.find(value => value.id === args.id);
          if (!item || !run.inputContextSnapshot) fail('PI_TOOL_PERMISSION', 'This input was not selected for the admitted run.');
          return { content: [{ type: 'text', text: JSON.stringify(item) }] };
        } });
      const propose = defineTool({ name: 'workspace_propose_action', description: 'Propose one selected connector action for exact human approval. This tool cannot execute, approve, wake Muse or send a message.',
        parameters: Type.Object({ content: Type.String({ minLength: 1, maxLength: 2000 }), connectorId: Type.String({ maxLength: 128 }), action: Type.String({ maxLength: 128 }), resource: Type.String({ maxLength: 2000 }), payload: Type.Record(Type.String(), Type.Unknown()) }), replay: 'safe', executionMode: 'sequential',
        execute: async (args, api, callContext) => {
          const run = assertActive(state.active);
          if (!state.active.structured || !run.connectorGrants?.some(grant => grant.connectorId === args.connectorId && grant.action === args.action)) fail('PI_TOOL_PERMISSION', 'This connector action was not selected for this run.');
          const proposal = { done: false, content: args.content, action: { connectorId: args.connectorId, action: args.action, resource: args.resource, payload: args.payload } };
          await api.commit(async tx => {
            const doc = await tx.doc(RecordDoc, api.conversationId);
            if (doc.active.proposal && capabilityPayloadHash(doc.active.proposal) !== capabilityPayloadHash(proposal)) fail('PI_TOOL_PERMISSION', 'Only one exact proposal may be returned per invocation.');
            doc.active.proposal = proposal;
          }, callContext);
          return { content: [{ type: 'text', text: 'Proposal recorded for original Workspace approval; no action executed.' }], control: { terminate: true } };
        } });
      const draftField = Type.Union(MUSE_DRAFT_FIELDS.map(value => Type.Literal(value)));
      const draftProposal = defineTool({ name: 'workspace_propose_muse_draft', replay: 'safe', executionMode: 'sequential',
        description: 'Record one INERT Muse draft from quoted selected facts. Unknown facts must be null; guesses are separate suggestions. This tool never creates, approves, dispatches an order or wakes/impersonates Muse. Invoke even with all-null scope to ask necessary missing fields.',
        parameters: Type.Object({ scope: Type.Object(Object.fromEntries(MUSE_DRAFT_FIELDS.map(field => [field, Type.Union([field === 'budgetCredits' ? Type.Integer({ minimum: 1, maximum: 10000 }) : Type.String({ maxLength: field === 'objective' ? 2500 : 240 }), Type.Null()])])), { additionalProperties: false }),
          sources: Type.Array(Type.Union([
            Type.Object({ field: draftField, kind: Type.Literal('message'), requestId: Type.String({ maxLength: 128 }), quote: Type.String({ minLength: 1, maxLength: 4000 }) }, { additionalProperties: false }),
            Type.Object({ field: draftField, kind: Type.Literal('artifact'), id: Type.String({ maxLength: 160 }), version: Type.Integer({ minimum: 1 }), sha256: Type.String({ pattern: '^[a-f0-9]{64}$' }), quote: Type.String({ minLength: 1, maxLength: 4000 }) }, { additionalProperties: false }),
          ]), { maxItems: 6 }), suggestions: Type.Optional(Type.Array(Type.Object({ field: draftField, value: Type.Union([Type.String({ maxLength: 2500 }), Type.Integer()]) }, { additionalProperties: false }), { maxItems: 6 })) }, { additionalProperties: false }),
        execute: async (args, api, callContext) => {
          const run = assertActive(state.active);
          if (!run.museDraftContext) fail('PI_TOOL_PERMISSION', 'This run did not select Muse draft preparation.');
          normalizeDraftProposal(args, run);
          await api.commit(async tx => {
            const doc = await tx.doc(RecordDoc, api.conversationId);
            if (doc.active.museDraftProposal && capabilityPayloadHash(doc.active.museDraftProposal) !== capabilityPayloadHash(args)) fail('PI_TOOL_PERMISSION', 'Only one exact inert draft proposal is permitted.');
            doc.active.museDraftProposal = clone(args);
          }, callContext);
          return { content: [{ type: 'text', text: 'Inert draft proposal saved for local factual checks and human review. No order, authorization, dispatch, wake or Muse execution occurred.' }], control: { terminate: true } };
        } });
      const supplierField = Type.Union(SUPPLIER_FIELDS.filter(field => field !== 'images').map(value => Type.Literal(value)));
      const supplierProposal = defineTool({ name: 'workspace_propose_supplier_profile', replay: 'safe', executionMode: 'sequential', description: 'Save private, quote-verified supplier product facts. Unknown stays null. This never grants public use, creates Shopify products, publishes or enables monitoring.',
        parameters: Type.Object({ facts: Type.Object(Object.fromEntries(SUPPLIER_FIELDS.filter(field => field !== 'images').map(field => [field, Type.Optional(Type.Union([Type.String({ maxLength: 4000 }), Type.Integer({ minimum: 0 }), Type.Null()]))])), { additionalProperties: false }),
          sources: Type.Array(Type.Object({ field: supplierField, kind: Type.Union([Type.Literal('message'), Type.Literal('artifact')]), requestId: Type.Optional(Type.String({ maxLength: 128 })), artifactId: Type.Optional(Type.String({ maxLength: 160 })), version: Type.Optional(Type.Integer({ minimum: 1 })), sha256: Type.Optional(Type.String({ pattern: '^[a-f0-9]{64}$' })), quote: Type.String({ minLength: 1, maxLength: 6000 }) }, { additionalProperties: false }), { maxItems: 18 }),
          suggestions: Type.Optional(Type.Array(Type.Object({ field: supplierField, value: Type.Union([Type.String({ maxLength: 500 }), Type.Integer()]) }, { additionalProperties: false }), { maxItems: 18 })) }, { additionalProperties: false }),
        execute: async (args, api, callContext) => {
          const run = assertActive(state.active);
          if (!run.supplierDraftContext) fail('PI_TOOL_PERMISSION', 'This invocation did not select supplier intake.');
          normalizeSupplierProposal(args, run);
          await api.commit(async tx => { const doc = await tx.doc(RecordDoc, api.conversationId); if (doc.active.supplierProposal && capabilityPayloadHash(doc.active.supplierProposal) !== capabilityPayloadHash(args)) fail('PI_TOOL_PERMISSION', 'Only one exact supplier proposal is admitted.'); doc.active.supplierProposal = clone(args); }, callContext);
          return { content: [{ type: 'text', text: 'Private supplier facts recorded. No public grant, Shopify write or monitor activation.' }], control: { terminate: true } };
        } });
      const extension = defineExtension({ name: 'workspace-governed', tools: [input, propose, draftProposal, supplierProposal], hooks: [
        hook(GenerationTask, { beforeRequest: async (request, api, callContext) => {
          assertActive(state.active);
          const doc = await api.snapshot(RecordDoc, api.conversationId, callContext);
          const tail = request.messages.filter(message => message.role !== 'system').slice(1);
          const answers = tail.filter(message => message.role === 'assistant');
          if (answers.length >= PI_REQUEST_LIMIT || !requestAllowance(doc.active)) fail('TOKEN_BUDGET', 'Pi reached the admitted request/output allowance.');
          return { messages: [request.messages[0], ...doc.active.messages, ...tail].filter(Boolean) };
        } }),
        hook(ToolTask, { beforeTool: call => {
          const run = assertActive(state.active);
          const allowed = run.supplierDraftContext ? ['workspace_input', 'workspace_propose_supplier_profile'] : run.museDraftContext ? ['workspace_input', 'workspace_propose_muse_draft'] : ['workspace_input', 'workspace_propose_action'];
          if (!allowed.includes(call.name)) return { block: 'Only the admitted Workspace input/proposal tools are permitted.' };
        } }),
      ] });
      registry.install(extension);
      state.extension = extension; state.input = input; state.propose = propose; state.draftProposal = draftProposal; state.supplierProposal = supplierProposal;
      try {
        harness = await Harness.open(storage, { models: governedModels, registry, settings: { retry: { enabled: false, maxRetries: 0 }, compaction: { enabled: false }, toolExecution: 'sequential', stream: { timeoutMs, maxRetries: 0 } } }, context);
        state.harness = harness; state.root = await harness.root(context);
        // No resume here: reopen is a read. Only an admitted complete() may start work.
        opened.set(conversationId, state);
        return state;
      } catch (error) { await (harness ? harness.close(context) : storage.close(context)); throw error; }
    })();
    opening.set(conversationId, operation);
    try { return await operation; } finally { opening.delete(conversationId); }
  }
  return {
    kind: 'pi-durable', provider: 'pi', configured: Boolean(suppliedModels ? modelRef : apiKey.trim()), model, models: [model],
    permissionFingerprint: capabilityPayloadHash({ ...POLICY, providerId, model, source: PI_SOURCE }),
    capabilities: ['pi-agent-context', 'pi-durable-execution', 'durable-request-dedupe', 'explicit-interruption-recovery', 'explicit-durable-abort', 'selected-replay-safe-tools', 'inert-muse-draft-proposals', 'private-supplier-profile-proposals'],
    setupMessage: 'Configure the existing host-managed FASTAITOKEN_API_KEY and PI_MODEL for Pi. Credentials remain on the server. Your work is saved.',
    limitations: ['Pi 1.1.0 is pinned; model endpoint/account access remains unverified.', 'Only selected input snapshots and exact action proposals are available to Pi. Workspace executes approved actions.', 'Reopen does not resume work automatically. User cancellation explicitly aborts durable work; shutdown preserves checkpoints.', 'Muse and Dot remain independent original connectors. A receipt or write submission is not wake/execution evidence.'],
    containsCredential: value => Boolean(apiKey && typeof value === 'string' && value.includes(apiKey)),
    async initialize({ store: originalStore }) {
      if (store || closing || !originalStore?.directory) throw new Error('Pi requires one original locked Workspace Store lifetime.');
      store = originalStore; directory = path.join(store.directory, 'pi'); await privateDirectory(directory);
    },
    async complete({ messages, model: requestedModel, maxTokens = 1600, signal, json = false, runId, conversationId, replyId, onEvent }) {
      if (!store || closing) fail('PI_NOT_ADMITTED', 'Pi is not attached to an open Workspace Store.');
      if (!this.configured) fail('SETUP_REQUIRED', this.setupMessage);
      if (requestedModel !== model || !modelRef) fail('INVALID_MODEL', 'Select the server-pinned Pi model.');
      if (typeof replyId !== 'string' || !Number.isInteger(maxTokens) || maxTokens < 1 || maxTokens > 1600) fail('PI_NOT_ADMITTED', 'Pi requires an admitted reply and bounded output budget.');
      if (activeCalls.has(conversationId)) fail('RUNTIME_BUSY', 'This Pi conversation already has admitted work.');
      const state = await openConversation(conversationId);
      if (activeCalls.has(conversationId)) fail('RUNTIME_BUSY', 'This Pi conversation already has admitted work.');
      const requestId = `${runId}:${replyId}`;
      const run = store.read().runs.find(value => value.id === runId);
      const scope = { runId, replyId, conversationId, executionHash: run?.executionHash, maxTokens, structured: json, museDraft: Boolean(run?.museDraftContext), supplierDraft: Boolean(run?.supplierDraftContext), snapshot: run?.inputContextSnapshot || null };
      assertActive(scope);
      const document = await state.harness.snapshot(RecordDoc, state.root.id, context);
      const previous = document?.records[requestId];
      const reattaching = Boolean(previous || document?.active?.requestId === requestId);
      let abortPromise;
      const localStop = new AbortController();
      const operation = { stop: () => localStop.abort('SHUTDOWN') };
      activeCalls.set(conversationId, operation);
      const cancelled = () => {
        // Cancelling wait alone leaves durable work running. User cancellation
        // aborts the actual conversation; shutdown closes without aborting it.
        const status = store.read().runs.find(value => value.id === runId)?.status;
        if (status !== 'interrupted' && !closing) abortPromise ||= state.root.abort(context);
        localStop.abort('STOPPED');
      };
      signal?.addEventListener('abort', cancelled, { once: true });
      try {
        if (reattaching) {
          if (document.active.requestId !== requestId || document.active.executionHash !== scope.executionHash) fail('EXECUTION_SCOPE_CHANGED', 'The persisted Pi invocation belongs to another execution scope.');
          state.active = clone(document.active);
        } else {
          // Stop an abandoned prior invocation before resetting its model context.
          if (document?.active) await state.root.abort(context);
          await state.root.reset(undefined, context);
          const systemPrompt = messages.filter(value => value.role === 'system').map(value => value.content).join('\n');
          const canonical = messages.filter(value => value.role !== 'system').map(value => value.role === 'assistant'
            ? { role: 'assistant', content: [{ type: 'text', text: value.content }], api: modelRef.api, provider: providerId, model, stopReason: 'stop', timestamp: Date.now(), usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 } } }
            : { role: 'user', content: value.content, timestamp: Date.now() });
          // Use the real Pi Agent state API for canonical context. pi-durable
          // owns execution and tools; no second Agent loop/scheduler is started.
          const agent = new Agent({ initialState: { model: modelRef, systemPrompt, messages: canonical }, streamFn: models.streamSimple.bind(models) });
          state.active = { ...scope, requestId, requests: [], messages: clone(agent.state.messages.filter(value => value.role !== 'system')) };
          await state.root.configure({ model: { provider: providerId, modelId: model }, instructions: systemPrompt,
            tools: scope.supplierDraft ? [state.input, state.supplierProposal] : scope.museDraft ? [state.input, state.draftProposal] : json ? [state.input, state.propose] : [state.input], extensions: [state.extension] }, context);
          await state.root.commit(async tx => { (await tx.doc(RecordDoc, state.root.id)).active = state.active; }, context);
        }
        if (signal?.aborted) cancelled();
        if (localStop.signal.aborted) fail('CANCELLED', 'The request was stopped.');
        const submission = previous ? await state.harness.submission(previous.submissionId, context)
          : await state.root.submit({ type: 'input', content: 'Continue the admitted Workspace request using only its selected inputs and permissions.', requestId, whenBusy: 'reject' }, context);
        if (!submission) fail('PI_CHECKPOINT_MISSING', 'The persisted Pi submission could not be found.');
        if (!previous) await state.root.commit(async tx => { (await tx.doc(RecordDoc, state.root.id)).records[requestId] = { submissionId: submission.id }; }, context);
        await onEvent?.({ type: 'pi.submission', piConversationId: state.root.id, piSubmissionId: submission.id, piRequestId: requestId });
        const settled = await submission.wait(withAbortSignal(localStop.signal, context));
        await abortPromise;
        if (localStop.signal.aborted || signal?.aborted) fail('CANCELLED', 'The request was stopped.');
        assertActive(state.active);
        const finalDoc = await state.harness.snapshot(RecordDoc, state.root.id, context);
        const entry = settled.answer ? await state.root.commit(tx => tx.entry(AssistantEntry, settled.answer), context) : null;
        const answer = entry?.model?.[0];
        if (scope.museDraft && !finalDoc.active.museDraftProposal) fail('PI_MUSE_PROPOSAL_REQUIRED', 'Pi must use its admitted inert draft tool; text cannot substitute for a draft or Muse execution.');
        if (scope.supplierDraft && !finalDoc.active.supplierProposal) fail('PI_SUPPLIER_PROPOSAL_REQUIRED', 'Pi must use its private quote-verified supplier tool.');
        const content = finalDoc.active.supplierProposal ? JSON.stringify({ done: true, content: 'Pi saved private supplier facts.' }) : finalDoc.active.museDraftProposal ? JSON.stringify({ done: true, content: 'Pi saved an inert proposal; no Muse execution.' })
          : finalDoc.active.proposal ? JSON.stringify(finalDoc.active.proposal) : answer?.content?.filter(value => value.type === 'text').map(value => value.text).join('');
        if (settled.status !== 'done' && !finalDoc.active.proposal && !finalDoc.active.museDraftProposal && !finalDoc.active.supplierProposal) fail('PI_UNANSWERED', `Pi did not complete this submission (${settled.reason || 'unanswered'}). Saved checkpoints remain available.`);
        if (answer?.stopReason === 'length') fail('OUTPUT_LIMIT', 'Pi reached the output limit. Review saved work before retrying.');
        if (!content?.trim() || content.length > 80000 || apiKey && content.includes(apiKey)) fail('INVALID_RESPONSE', 'Pi returned an invalid visible answer.');
        const totals = invocationUsage(finalDoc.active.requests);
        return { content, usage: totals, ...(scope.museDraft ? { museDraftProposal: clone(finalDoc.active.museDraftProposal) } : {}), ...(scope.supplierDraft ? { supplierProposal: clone(finalDoc.active.supplierProposal) } : {}), runtime: { kind: 'pi-durable', version: PI_VERSION, source: PI_SOURCE, submissionId: submission.id, replayed: reattaching } };
      } catch (error) {
        await abortPromise?.catch(() => {});
        if (localStop.signal.aborted || signal?.aborted) fail('CANCELLED', 'The request was stopped.');
        if (error instanceof ProviderError || error?.code) throw error;
        const failure = new ProviderError('PI_RUNTIME_ERROR', 'Pi could not complete this invocation. Inspect saved local diagnostics; no unreviewed action was executed.'); failure.cause = error; throw failure;
      } finally { signal?.removeEventListener('abort', cancelled); activeCalls.delete(conversationId); state.active = null; }
    },
    close() {
      if (closePromise) return closePromise;
      closing = true;
      for (const value of activeCalls.values()) value.stop();
      closePromise = (async () => {
        await Promise.allSettled([...opening.values()]);
        for (const state of opened.values()) { await state.harness.close(context); await privateDirectory(state.location); }
        opened.clear();
      })();
      return closePromise;
    },
  };
}
